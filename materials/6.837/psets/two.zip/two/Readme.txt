Compiling and runnning:
Simply cd into the directory containing my code and run the command "make" to compile. Run by executing "./a2" followed by the prefix to the name of the files you would like displayed. e.g. "data/Model1"

Collaboration:
I did not collaborate.

Resources:
Again, cplusplus.com was my most used resource.

Known Problems:
My code only attempts in implement aspects of the code through the display of joints. I have not had a chance to test this thoroughly, and, although the joints are not being displayed, I believe it is because of a silly error like not specifying certain attributes of the sphere necessary to display them. Then again, it could be something deeper.

Extra Credit:
Having, embarrassingly, not even finished the main assignment, I did not attempt the extra credit.

Comments:
I would have loved to do more of this but put my time into running Startup Bootcamp at MIT.... My fault. Other than tha, I'm a fan.
