Compiling:
Compiling the code is simply. Simply run cd into the directory containing the .cpp and .h files and execute "make".

Running:
Compiling will have created an executable file called "a1". Run it to render a .swp file by executing "./a1 path/to/swp/file"

Collaboration:
I did not collaborate with anyone in the class on this assignment.

References:
The lecture notes and slides
http://en.cppreference.com/w/
stackoverflow.com
www.cplusplus.com

Known Issues
There are no known issues in my code. I did not fix the issue that causes continuous curves to have a seam, and I find this frustrating, but it was not a required fix for the assignment.

Extra Credit:
I did not implement any of the extra credit.

Comments:
Loved it! Too cool.
